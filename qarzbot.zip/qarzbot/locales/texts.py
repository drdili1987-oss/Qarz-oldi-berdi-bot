"""Bot ichidagi barcha matnlar. Har bir kalit uz/ru/kk tillarida mavjud bo'lishi shart."""

TEXTS = {
    "uz": {
        # --- Ro'yxatdan o'tish ---
        "choose_language": "Assalomu alaykum! 👋\nTilni tanlang:",
        "invalid_language": "Iltimos, quyidagi tugmalardan birini tanlang 👇",
        "name_request": "Ismingiz va familiyangizni kiriting:",
        "invalid_name": "Ism juda qisqa. Qaytadan kiriting:",
        "phone_request": "Endi telefon raqamingizni yuboring 👇",
        "send_contact_btn": "📱 Raqamni yuborish",
        "invalid_phone": "Iltimos, «📱 Raqamni yuborish» tugmasi orqali kontakt yuboring.",
        "invalid_contact": "Iltimos, o'zingizning kontaktingizni yuboring, boshqa birovnikini emas.",
        "registered_welcome": "Xush kelibsiz, {name}! ✅\nRo'yxatdan muvaffaqiyatli o'tdingiz.",
        "main_menu_title": "🏠 Asosiy menyu",

        # --- Tugmalar ---
        "btn_creditors": "👥 Haqdorlarim",
        "btn_debtors": "👤 Qarzdorlarim",
        "btn_history": "📊 Qarzlar tarixi",
        "btn_income": "📥 Kirim",
        "btn_outcome": "📤 Chiqim",
        "btn_cancel": "❌ Bekor qilish",
        "btn_confirm": "✅ Tasdiqlash",
        "btn_reject": "❌ Bekor qilish",
        "btn_add_new": "➕ Yangi qo'shish",

        # --- Haqdorlar / Qarzdorlar ro'yxati ---
        "no_creditors": "Sizda hozircha haqdorlar (siz qarzdor bo'lgan shaxslar) yo'q.",
        "no_debtors": "Sizda hozircha qarzdorlar yo'q.",
        "creditors_title": "👥 <b>Haqdorlaringiz</b> (siz ularga qarzdorsiz):",
        "debtors_title": "👤 <b>Qarzdorlaringiz</b> (ular sizga qarzdor):",
        "pending_person": "Kutilmoqda (hali qo'shilmagan)",
        "status_pending": "tasdiqlanmagan",
        "status_active": "faol",

        # --- Tarix ---
        "no_history": "Tarix hozircha bo'sh.",
        "history_title": "📊 <b>Qarzlar tarixi</b> (oxirgi 30 ta):",

        # --- Qarz qo'shish ---
        "enter_recipient": (
            "Ikkinchi tomonning Telegram ID raqamini, @username'ini yoki kontaktini yuboring:"
        ),
        "cancelled": "Bekor qilindi.",
        "cannot_add_self": "O'zingizni qo'sha olmaysiz.",
        "choose_currency": "Valyutani tanlang:",
        "enter_amount": "Summani kiriting (faqat raqam):",
        "invalid_amount": "Noto'g'ri summa. Iltimos, musbat raqam kiriting:",
        "role_creditor": "sizdan qarzdor bo'lishni",
        "role_debtor": "sizga qarz berishni",
        "debt_confirm_request": (
            "🔔 <b>{name}</b> sizni {role} bildirdi.\n"
            "Summasi: <b>{amount} {currency}</b>\n\n"
            "Tasdiqlaysizmi?"
        ),
        "debt_incoming_request": (
            "🔔 <b>{name}</b> sizga qarz so'rovi yubordi.\n"
            "Summasi: <b>{amount} {currency}</b>\n\n"
            "Tasdiqlaysizmi?"
        ),
        "debt_request_sent": "So'rov yuborildi. Tasdiqlashini kuting.",
        "debt_request_send_failed": (
            "So'rovni yuborib bo'lmadi. Ehtimol, foydalanuvchi botni bloklagan."
        ),
        "debt_link_generated": (
            "Bu foydalanuvchi botda topilmadi.\n"
            "Quyidagi havolani unga yuboring, u kirib tasdiqlagach qarz faollashadi:\n\n{link}"
        ),
        "debt_not_found": "Bu qarz topilmadi yoki allaqachon ko'rib chiqilgan.",
        "debt_confirmed_by_you": "✅ Siz tasdiqladingiz. Qarz faollashtirildi.",
        "debt_confirmed_by_other": "✅ <b>{name}</b> qarzni tasdiqladi. Endi u faol.",
        "debt_rejected_by_you": "❌ Siz rad etdingiz.",
        "debt_rejected_by_other": "❌ <b>{name}</b> qarz so'rovini rad etdi.",

        # --- Kirim / Chiqim ---
        "no_active_debtors": "Sizga hech kim qarzdor emas (faol qarzlar yo'q).",
        "no_active_creditors": "Siz hech kimga qarzdor emassiz (faol qarzlar yo'q).",
        "choose_person_income": "Kimdan pul qabul qildingiz? Tanlang:",
        "choose_person_outcome": "Kimga to'lov qildingiz? Tanlang:",
        "enter_payment_amount": "Summani kiriting (maksimal: {max_amount} {currency}):",
        "invalid_payment_amount": (
            "Noto'g'ri summa. 0 dan katta va {max_amount} dan oshmagan raqam kiriting:"
        ),
        "payment_type_income": "sizga pul berdi",
        "payment_type_outcome": "sizdan pul oldi / siz unga to'ladingiz",
        "payment_confirm_request": (
            "🔔 <b>{name}</b> {type} deb bildirdi.\n"
            "Summasi: <b>{amount} {currency}</b>\n\n"
            "Tasdiqlaysizmi?"
        ),
        "payment_request_sent": "So'rov yuborildi. Tasdiqlashini kuting.",
        "payment_confirmed_by_you": "✅ Tasdiqlandi.",
        "payment_confirmed_by_other": "✅ <b>{name}</b> {amount} {currency} to'lovni tasdiqladi.",
        "debt_fully_closed": "🎉 Qarz to'liq yopildi!",
        "debt_partially_closed": "Qolgan qarz: {remaining} {currency}",
        "payment_rejected_by_you": "❌ Rad etildi.",
        "payment_rejected_by_other": "❌ <b>{name}</b> to'lovni rad etdi.",

        # --- Eslatma ---
        "debt_reminder": (
            "⏰ Hurmatli foydalanuvchi, sizda <b>{name}</b> oldida "
            "<b>{amount} {currency}</b> miqdorida qarz mavjud. "
            "Iltimos, imkon qadar tezroq to'lashga harakat qiling. 🙏"
        ),

        # --- Admin ---
        "not_admin": "Bu buyruq faqat admin uchun.",
        "admin_stats": (
            "📊 <b>Statistika</b>\n\n"
            "👤 Jami foydalanuvchilar: {total_users}\n"
            "💳 Faol qarzlar soni: {active_debts}\n"
            "💰 Umumiy aylanma (UZS): {total_uzs}\n"
            "💵 Umumiy aylanma (USD): {total_usd}"
        ),
        "broadcast_prompt": "Barcha foydalanuvchilarga yuborilishi kerak bo'lgan xabar matnini kiriting:",
        "broadcast_preview": "Quyidagi xabar barcha foydalanuvchilarga yuboriladi:\n\n{text}",
        "broadcast_done": "✅ Yuborildi: {sent} ta.\n❌ Xatolik: {failed} ta.",
        "broadcast_cancelled": "Broadcast bekor qilindi.",
    },
    "ru": {
        "choose_language": "Здравствуйте! 👋\nВыберите язык:",
        "invalid_language": "Пожалуйста, выберите одну из кнопок ниже 👇",
        "name_request": "Введите ваше имя и фамилию:",
        "invalid_name": "Имя слишком короткое. Введите заново:",
        "phone_request": "Теперь отправьте номер телефона 👇",
        "send_contact_btn": "📱 Отправить номер",
        "invalid_phone": "Пожалуйста, отправьте контакт через кнопку «📱 Отправить номер».",
        "invalid_contact": "Пожалуйста, отправьте свой собственный контакт.",
        "registered_welcome": "Добро пожаловать, {name}! ✅\nВы успешно зарегистрированы.",
        "main_menu_title": "🏠 Главное меню",

        "btn_creditors": "👥 Мои кредиторы",
        "btn_debtors": "👤 Мои должники",
        "btn_history": "📊 История долгов",
        "btn_income": "📥 Приход",
        "btn_outcome": "📤 Расход",
        "btn_cancel": "❌ Отмена",
        "btn_confirm": "✅ Подтвердить",
        "btn_reject": "❌ Отклонить",
        "btn_add_new": "➕ Добавить нового",

        "no_creditors": "У вас пока нет кредиторов (тех, кому вы должны).",
        "no_debtors": "У вас пока нет должников.",
        "creditors_title": "👥 <b>Ваши кредиторы</b> (вы им должны):",
        "debtors_title": "👤 <b>Ваши должники</b> (они должны вам):",
        "pending_person": "Ожидается (ещё не присоединился)",
        "status_pending": "не подтверждено",
        "status_active": "активен",

        "no_history": "История пока пуста.",
        "history_title": "📊 <b>История долгов</b> (последние 30):",

        "enter_recipient": "Отправьте Telegram ID, @username или контакт второй стороны:",
        "cancelled": "Отменено.",
        "cannot_add_self": "Нельзя добавить самого себя.",
        "choose_currency": "Выберите валюту:",
        "enter_amount": "Введите сумму (только число):",
        "invalid_amount": "Неверная сумма. Введите положительное число:",
        "role_creditor": "что вы должны ему",
        "role_debtor": "что он должен вам",
        "debt_confirm_request": (
            "🔔 <b>{name}</b> указал, {role}.\n"
            "Сумма: <b>{amount} {currency}</b>\n\n"
            "Подтверждаете?"
        ),
        "debt_incoming_request": (
            "🔔 <b>{name}</b> отправил вам запрос на долг.\n"
            "Сумма: <b>{amount} {currency}</b>\n\n"
            "Подтверждаете?"
        ),
        "debt_request_sent": "Запрос отправлен. Ожидайте подтверждения.",
        "debt_request_send_failed": "Не удалось отправить запрос. Возможно, пользователь заблокировал бота.",
        "debt_link_generated": (
            "Этот пользователь не найден в боте.\n"
            "Отправьте ему следующую ссылку, после перехода и подтверждения долг активируется:\n\n{link}"
        ),
        "debt_not_found": "Долг не найден или уже обработан.",
        "debt_confirmed_by_you": "✅ Вы подтвердили. Долг активирован.",
        "debt_confirmed_by_other": "✅ <b>{name}</b> подтвердил долг. Теперь он активен.",
        "debt_rejected_by_you": "❌ Вы отклонили.",
        "debt_rejected_by_other": "❌ <b>{name}</b> отклонил запрос на долг.",

        "no_active_debtors": "Вам никто не должен (нет активных долгов).",
        "no_active_creditors": "Вы никому не должны (нет активных долгов).",
        "choose_person_income": "От кого вы получили деньги? Выберите:",
        "choose_person_outcome": "Кому вы заплатили? Выберите:",
        "enter_payment_amount": "Введите сумму (максимум: {max_amount} {currency}):",
        "invalid_payment_amount": "Неверная сумма. Введите число больше 0 и не более {max_amount}:",
        "payment_type_income": "передал(а) вам деньги",
        "payment_type_outcome": "получил(а) от вас деньги / вы оплатили",
        "payment_confirm_request": (
            "🔔 <b>{name}</b> указал(а), что {type}.\n"
            "Сумма: <b>{amount} {currency}</b>\n\n"
            "Подтверждаете?"
        ),
        "payment_request_sent": "Запрос отправлен. Ожидайте подтверждения.",
        "payment_confirmed_by_you": "✅ Подтверждено.",
        "payment_confirmed_by_other": "✅ <b>{name}</b> подтвердил(а) платёж {amount} {currency}.",
        "debt_fully_closed": "🎉 Долг полностью закрыт!",
        "debt_partially_closed": "Остаток долга: {remaining} {currency}",
        "payment_rejected_by_you": "❌ Отклонено.",
        "payment_rejected_by_other": "❌ <b>{name}</b> отклонил(а) платёж.",

        "debt_reminder": (
            "⏰ Уважаемый пользователь, у вас есть долг перед <b>{name}</b> "
            "в размере <b>{amount} {currency}</b>. "
            "Пожалуйста, постарайтесь погасить его как можно скорее. 🙏"
        ),

        "not_admin": "Эта команда доступна только администратору.",
        "admin_stats": (
            "📊 <b>Статистика</b>\n\n"
            "👤 Всего пользователей: {total_users}\n"
            "💳 Активных долгов: {active_debts}\n"
            "💰 Общий оборот (UZS): {total_uzs}\n"
            "💵 Общий оборот (USD): {total_usd}"
        ),
        "broadcast_prompt": "Введите текст сообщения для рассылки всем пользователям:",
        "broadcast_preview": "Это сообщение будет отправлено всем пользователям:\n\n{text}",
        "broadcast_done": "✅ Отправлено: {sent}.\n❌ Ошибок: {failed}.",
        "broadcast_cancelled": "Рассылка отменена.",
    },
    "kk": {
        "choose_language": "Сәлеметсіз бе! 👋\nТілді таңдаңыз:",
        "invalid_language": "Төмендегі түймелердің бірін таңдаңыз 👇",
        "name_request": "Атыңыз бен тегіңізді енгізіңіз:",
        "invalid_name": "Аты тым қысқа. Қайта енгізіңіз:",
        "phone_request": "Енді телефон нөміріңізді жіберіңіз 👇",
        "send_contact_btn": "📱 Нөмірді жіберу",
        "invalid_phone": "Өтінеміз, «📱 Нөмірді жіберу» түймесі арқылы контакт жіберіңіз.",
        "invalid_contact": "Өз контактіңізді жіберіңіз, басқа адамдікін емес.",
        "registered_welcome": "Қош келдіңіз, {name}! ✅\nСіз сәтті тіркелдіңіз.",
        "main_menu_title": "🏠 Басты мәзір",

        "btn_creditors": "👥 Несие берушілерім",
        "btn_debtors": "👤 Борышқорларым",
        "btn_history": "📊 Қарыздар тарихы",
        "btn_income": "📥 Кіріс",
        "btn_outcome": "📤 Шығыс",
        "btn_cancel": "❌ Бас тарту",
        "btn_confirm": "✅ Растау",
        "btn_reject": "❌ Қабылдамау",
        "btn_add_new": "➕ Жаңасын қосу",

        "no_creditors": "Сізде әзірге несие берушілер жоқ (сіз қарыз болған адамдар).",
        "no_debtors": "Сізде әзірге борышқорлар жоқ.",
        "creditors_title": "👥 <b>Несие берушілеріңіз</b> (сіз оларға қарызсыз):",
        "debtors_title": "👤 <b>Борышқорларыңыз</b> (олар сізге қарыз):",
        "pending_person": "Күтілуде (әлі қосылмаған)",
        "status_pending": "расталмаған",
        "status_active": "белсенді",

        "no_history": "Тарих әзірге бос.",
        "history_title": "📊 <b>Қарыздар тарихы</b> (соңғы 30):",

        "enter_recipient": "Екінші тараптың Telegram ID, @username немесе контактісін жіберіңіз:",
        "cancelled": "Бас тартылды.",
        "cannot_add_self": "Өзіңізді қоса алмайсыз.",
        "choose_currency": "Валютаны таңдаңыз:",
        "enter_amount": "Соманы енгізіңіз (тек сан):",
        "invalid_amount": "Қате сома. Оң сан енгізіңіз:",
        "role_creditor": "сізден қарыз алуды",
        "role_debtor": "сізге қарыз беруді",
        "debt_confirm_request": (
            "🔔 <b>{name}</b> {role} білдірді.\n"
            "Сомасы: <b>{amount} {currency}</b>\n\n"
            "Растайсыз ба?"
        ),
        "debt_incoming_request": (
            "🔔 <b>{name}</b> сізге қарыз сұрауын жіберді.\n"
            "Сомасы: <b>{amount} {currency}</b>\n\n"
            "Растайсыз ба?"
        ),
        "debt_request_sent": "Сұрау жіберілді. Растауын күтіңіз.",
        "debt_request_send_failed": "Сұрауды жіберу мүмкін болмады. Мүмкін, пайдаланушы ботты бұғаттаған.",
        "debt_link_generated": (
            "Бұл пайдаланушы ботта табылмады.\n"
            "Төмендегі сілтемені оған жіберіңіз, ол кіріп растаған соң қарыз белсенді болады:\n\n{link}"
        ),
        "debt_not_found": "Бұл қарыз табылмады немесе қаралып қойылған.",
        "debt_confirmed_by_you": "✅ Сіз растадыңыз. Қарыз белсендірілді.",
        "debt_confirmed_by_other": "✅ <b>{name}</b> қарызды растады. Енді ол белсенді.",
        "debt_rejected_by_you": "❌ Сіз қабылдамадыңыз.",
        "debt_rejected_by_other": "❌ <b>{name}</b> қарыз сұрауын қабылдамады.",

        "no_active_debtors": "Сізге ешкім қарыз емес (белсенді қарыздар жоқ).",
        "no_active_creditors": "Сіз ешкімге қарыз емессіз (белсенді қарыздар жоқ).",
        "choose_person_income": "Кімнен ақша алдыңыз? Таңдаңыз:",
        "choose_person_outcome": "Кімге төлем жасадыңыз? Таңдаңыз:",
        "enter_payment_amount": "Соманы енгізіңіз (максимум: {max_amount} {currency}):",
        "invalid_payment_amount": "Қате сома. 0-ден үлкен және {max_amount}-ден аспайтын сан енгізіңіз:",
        "payment_type_income": "сізге ақша берді",
        "payment_type_outcome": "сізден ақша алды / сіз төледіңіз",
        "payment_confirm_request": (
            "🔔 <b>{name}</b> {type} деп білдірді.\n"
            "Сомасы: <b>{amount} {currency}</b>\n\n"
            "Растайсыз ба?"
        ),
        "payment_request_sent": "Сұрау жіберілді. Растауын күтіңіз.",
        "payment_confirmed_by_you": "✅ Расталды.",
        "payment_confirmed_by_other": "✅ <b>{name}</b> {amount} {currency} төлемді растады.",
        "debt_fully_closed": "🎉 Қарыз толық жабылды!",
        "debt_partially_closed": "Қалған қарыз: {remaining} {currency}",
        "payment_rejected_by_you": "❌ Қабылданбады.",
        "payment_rejected_by_other": "❌ <b>{name}</b> төлемді қабылдамады.",

        "debt_reminder": (
            "⏰ Құрметті пайдаланушы, сізде <b>{name}</b> алдында "
            "<b>{amount} {currency}</b> мөлшерінде қарыз бар. "
            "Оны мүмкіндігінше тезірек өтеуге тырысыңыз. 🙏"
        ),

        "not_admin": "Бұл команда тек әкімші үшін.",
        "admin_stats": (
            "📊 <b>Статистика</b>\n\n"
            "👤 Барлық пайдаланушылар: {total_users}\n"
            "💳 Белсенді қарыздар саны: {active_debts}\n"
            "💰 Жалпы айналым (UZS): {total_uzs}\n"
            "💵 Жалпы айналым (USD): {total_usd}"
        ),
        "broadcast_prompt": "Барлық пайдаланушыларға жіберілетін хабарлама мәтінін енгізіңіз:",
        "broadcast_preview": "Бұл хабарлама барлық пайдаланушыларға жіберіледі:\n\n{text}",
        "broadcast_done": "✅ Жіберілді: {sent}.\n❌ Қателер: {failed}.",
        "broadcast_cancelled": "Broadcast бас тартылды.",
    },
}
