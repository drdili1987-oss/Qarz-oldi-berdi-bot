"""
Firebase Realtime Database bilan ishlash uchun barcha funksiyalar.

Baza strukturasi:
    users/{user_id}   -> user_id, full_name, phone_number, username, language, created_at
    debts/{debt_id}   -> debt_id, debtor_id, creditor_id, amount, currency,
                          status ('pending'|'active'|'closed'), last_notified_at, created_at
    history/{trans_id}-> trans_id, debt_id, from_user, to_user,
                          type ('borrow'|'lend'|'income'|'outcome'),
                          amount, currency, status, timestamp
"""

import json
import os
import uuid
from datetime import datetime, timezone
from typing import Optional

import firebase_admin
from firebase_admin import credentials, db

from config import FIREBASE_CREDENTIALS_JSON, FIREBASE_CREDENTIALS_PATH, FIREBASE_DB_URL

USERS_REF = "users"
DEBTS_REF = "debts"
HISTORY_REF = "history"


def _init_firebase() -> None:
    if firebase_admin._apps:
        return

    if FIREBASE_CREDENTIALS_JSON:
        cred_dict = json.loads(FIREBASE_CREDENTIALS_JSON)
        cred = credentials.Certificate(cred_dict)
    elif os.path.exists(FIREBASE_CREDENTIALS_PATH):
        cred = credentials.Certificate(FIREBASE_CREDENTIALS_PATH)
    else:
        raise RuntimeError(
            "Firebase credentials topilmadi. FIREBASE_CREDENTIALS_JSON "
            "(to'liq JSON matn) yoki FIREBASE_CREDENTIALS_PATH (fayl yo'li) "
            "environment variable'larini sozlang."
        )

    firebase_admin.initialize_app(cred, {"databaseURL": FIREBASE_DB_URL})


_init_firebase()


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


# ==================== USERS ====================

def get_user(user_id: int) -> Optional[dict]:
    if not user_id:
        return None
    return db.reference(f"{USERS_REF}/{user_id}").get()


def user_exists(user_id: int) -> bool:
    return get_user(user_id) is not None


def create_user(
    user_id: int,
    full_name: str,
    phone_number: str,
    language: str,
    username: str = "",
) -> None:
    db.reference(f"{USERS_REF}/{user_id}").set(
        {
            "user_id": user_id,
            "full_name": full_name,
            "phone_number": phone_number,
            "username": username or "",
            "language": language,
            "created_at": _now_iso(),
        }
    )


def update_user_language(user_id: int, language: str) -> None:
    db.reference(f"{USERS_REF}/{user_id}/language").set(language)


def get_user_language(user_id: int) -> str:
    lang = db.reference(f"{USERS_REF}/{user_id}/language").get()
    return lang if lang in ("uz", "ru", "kk") else "uz"


def find_user_by_username(username: str) -> Optional[dict]:
    """Realtime Database'da username bo'yicha indeks bo'lmagani sababli
    to'liq scan qilinadi. Foydalanuvchilar soni juda katta bo'lsa,
    alohida `usernames/{username} -> user_id` indeks jadvali qo'shish tavsiya etiladi."""
    username = username.lstrip("@").lower()
    if not username:
        return None
    all_users = db.reference(USERS_REF).get() or {}
    for _, udata in all_users.items():
        if str(udata.get("username", "")).lower() == username:
            return udata
    return None


def get_all_users() -> dict:
    return db.reference(USERS_REF).get() or {}


# ==================== DEBTS ====================

def create_debt(
    debtor_id: Optional[int],
    creditor_id: Optional[int],
    amount: float,
    currency: str,
    status: str = "pending",
) -> str:
    debt_id = str(uuid.uuid4())
    db.reference(f"{DEBTS_REF}/{debt_id}").set(
        {
            "debt_id": debt_id,
            "debtor_id": debtor_id,
            "creditor_id": creditor_id,
            "amount": amount,
            "currency": currency,
            "status": status,
            "last_notified_at": _now_iso(),
            "created_at": _now_iso(),
        }
    )
    return debt_id


def get_debt(debt_id: str) -> Optional[dict]:
    debt = db.reference(f"{DEBTS_REF}/{debt_id}").get()
    if debt:
        debt["debt_id"] = debt_id
    return debt


def update_debt_status(debt_id: str, status: str) -> None:
    db.reference(f"{DEBTS_REF}/{debt_id}/status").set(status)


def update_debt_amount(debt_id: str, new_amount: float) -> None:
    db.reference(f"{DEBTS_REF}/{debt_id}/amount").set(new_amount)


def update_debt_notified(debt_id: str) -> None:
    db.reference(f"{DEBTS_REF}/{debt_id}/last_notified_at").set(_now_iso())


def set_debt_debtor(debt_id: str, debtor_id: int) -> None:
    db.reference(f"{DEBTS_REF}/{debt_id}/debtor_id").set(debtor_id)


def set_debt_creditor(debt_id: str, creditor_id: int) -> None:
    db.reference(f"{DEBTS_REF}/{debt_id}/creditor_id").set(creditor_id)


def delete_debt(debt_id: str) -> None:
    db.reference(f"{DEBTS_REF}/{debt_id}").delete()


def get_all_debts() -> dict:
    return db.reference(DEBTS_REF).get() or {}


def get_debts_by_debtor(user_id: int, status: Optional[str] = None) -> list:
    all_debts = get_all_debts()
    result = []
    for debt_id, d in all_debts.items():
        if d.get("debtor_id") == user_id and (status is None or d.get("status") == status):
            d = dict(d)
            d["debt_id"] = debt_id
            result.append(d)
    return result


def get_debts_by_creditor(user_id: int, status: Optional[str] = None) -> list:
    all_debts = get_all_debts()
    result = []
    for debt_id, d in all_debts.items():
        if d.get("creditor_id") == user_id and (status is None or d.get("status") == status):
            d = dict(d)
            d["debt_id"] = debt_id
            result.append(d)
    return result


# ==================== HISTORY ====================

def add_history(
    debt_id: str,
    from_user: int,
    to_user: int,
    type_: str,
    amount: float,
    currency: str,
    status: str = "confirmed",
) -> str:
    trans_id = str(uuid.uuid4())
    db.reference(f"{HISTORY_REF}/{trans_id}").set(
        {
            "trans_id": trans_id,
            "debt_id": debt_id,
            "from_user": from_user,
            "to_user": to_user,
            "type": type_,
            "amount": amount,
            "currency": currency,
            "status": status,
            "timestamp": _now_iso(),
        }
    )
    return trans_id


def get_history_by_user(user_id: int) -> list:
    all_history = db.reference(HISTORY_REF).get() or {}
    result = []
    for trans_id, h in all_history.items():
        if h.get("from_user") == user_id or h.get("to_user") == user_id:
            h = dict(h)
            h["trans_id"] = trans_id
            result.append(h)
    result.sort(key=lambda x: x.get("timestamp", ""), reverse=True)
    return result


# ==================== ADMIN STATISTIKA ====================

def get_stats() -> dict:
    users = get_all_users()
    debts = get_all_debts()
    active_debts = [d for d in debts.values() if d.get("status") == "active"]
    total_uzs = sum(d.get("amount", 0) for d in active_debts if d.get("currency") == "UZS")
    total_usd = sum(d.get("amount", 0) for d in active_debts if d.get("currency") == "USD")
    return {
        "total_users": len(users),
        "active_debts_count": len(active_debts),
        "total_uzs": total_uzs,
        "total_usd": total_usd,
    }
