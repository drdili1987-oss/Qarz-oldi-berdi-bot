from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from locales.texts import TEXTS


def currency_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="🇺🇿 UZS", callback_data="currency_UZS"),
                InlineKeyboardButton(text="💵 USD", callback_data="currency_USD"),
            ]
        ]
    )


def debt_confirm_keyboard(lang: str, debt_id: str) -> InlineKeyboardMarkup:
    t = TEXTS[lang]
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text=t["btn_confirm"], callback_data=f"debt_confirm_{debt_id}"),
                InlineKeyboardButton(text=t["btn_reject"], callback_data=f"debt_reject_{debt_id}"),
            ]
        ]
    )


def payment_confirm_keyboard(lang: str, debt_id: str, amount: float) -> InlineKeyboardMarkup:
    t = TEXTS[lang]
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=t["btn_confirm"], callback_data=f"pay_confirm_{debt_id}_{amount}"
                ),
                InlineKeyboardButton(
                    text=t["btn_reject"], callback_data=f"pay_reject_{debt_id}_{amount}"
                ),
            ]
        ]
    )


def add_button_keyboard(lang: str, role: str) -> InlineKeyboardMarkup:
    t = TEXTS[lang]
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=t["btn_add_new"], callback_data=f"add_debt_{role}")]
        ]
    )


def person_list_keyboard(people: list, prefix: str) -> InlineKeyboardMarkup:
    rows = []
    for p in people:
        label = f"{p['name']} ({p['amount']} {p['currency']})"
        rows.append([InlineKeyboardButton(text=label, callback_data=f"{prefix}_{p['debt_id']}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def broadcast_confirm_keyboard(lang: str) -> InlineKeyboardMarkup:
    t = TEXTS[lang]
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text=t["btn_confirm"], callback_data="broadcast_confirm"),
                InlineKeyboardButton(text=t["btn_reject"], callback_data="broadcast_cancel"),
            ]
        ]
    )
