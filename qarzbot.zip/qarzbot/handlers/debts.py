from aiogram import Bot, F, Router
from aiogram.enums import ContentType
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

import database as db
from config import BOT_USERNAME
from keyboards.default import cancel_keyboard, main_menu_keyboard
from keyboards.inline import add_button_keyboard, currency_keyboard, debt_confirm_keyboard
from locales.texts import TEXTS
from states import AddDebt

router = Router(name="debts")

ALL_BTN_CREDITORS = [t["btn_creditors"] for t in TEXTS.values()]
ALL_BTN_DEBTORS = [t["btn_debtors"] for t in TEXTS.values()]
ALL_BTN_HISTORY = [t["btn_history"] for t in TEXTS.values()]
ALL_BTN_CANCEL = [t["btn_cancel"] for t in TEXTS.values()]


@router.message(StateFilter(None), F.text.in_(ALL_BTN_CREDITORS))
async def show_creditors(message: Message) -> None:
    user_id = message.from_user.id
    lang = db.get_user_language(user_id)
    debts = [d for d in db.get_debts_by_debtor(user_id) if d.get("status") in ("active", "pending")]

    if not debts:
        await message.answer(TEXTS[lang]["no_creditors"], reply_markup=add_button_keyboard(lang, "creditor"))
        return

    lines = [TEXTS[lang]["creditors_title"]]
    for d in debts:
        creditor = db.get_user(d["creditor_id"]) if d.get("creditor_id") else None
        name = creditor["full_name"] if creditor else TEXTS[lang]["pending_person"]
        status_text = (
            TEXTS[lang]["status_pending"] if d["status"] == "pending" else TEXTS[lang]["status_active"]
        )
        lines.append(f"• {name}: {d['amount']} {d['currency']} [{status_text}]")

    await message.answer("\n".join(lines), reply_markup=add_button_keyboard(lang, "creditor"))


@router.message(StateFilter(None), F.text.in_(ALL_BTN_DEBTORS))
async def show_debtors(message: Message) -> None:
    user_id = message.from_user.id
    lang = db.get_user_language(user_id)
    debts = [d for d in db.get_debts_by_creditor(user_id) if d.get("status") in ("active", "pending")]

    if not debts:
        await message.answer(TEXTS[lang]["no_debtors"], reply_markup=add_button_keyboard(lang, "debtor"))
        return

    lines = [TEXTS[lang]["debtors_title"]]
    for d in debts:
        debtor = db.get_user(d["debtor_id"]) if d.get("debtor_id") else None
        name = debtor["full_name"] if debtor else TEXTS[lang]["pending_person"]
        status_text = (
            TEXTS[lang]["status_pending"] if d["status"] == "pending" else TEXTS[lang]["status_active"]
        )
        lines.append(f"• {name}: {d['amount']} {d['currency']} [{status_text}]")

    await message.answer("\n".join(lines), reply_markup=add_button_keyboard(lang, "debtor"))


@router.message(StateFilter(None), F.text.in_(ALL_BTN_HISTORY))
async def show_history(message: Message) -> None:
    user_id = message.from_user.id
    lang = db.get_user_language(user_id)
    history = db.get_history_by_user(user_id)

    if not history:
        await message.answer(TEXTS[lang]["no_history"])
        return

    lines = [TEXTS[lang]["history_title"]]
    for h in history[:30]:
        direction = "➡️" if h["from_user"] == user_id else "⬅️"
        lines.append(f"{direction} {h['type']}: {h['amount']} {h['currency']} ({h['status']})")

    await message.answer("\n".join(lines))


@router.callback_query(F.data.startswith("add_debt_"))
async def start_add_debt(callback: CallbackQuery, state: FSMContext) -> None:
    role = callback.data.replace("add_debt_", "", 1)  # "creditor" yoki "debtor"
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id)

    await state.update_data(role=role)
    await state.set_state(AddDebt.entering_recipient)
    await callback.message.answer(TEXTS[lang]["enter_recipient"], reply_markup=cancel_keyboard(lang))
    await callback.answer()


async def _process_recipient(message: Message, state: FSMContext, target_id) -> None:
    user_id = message.from_user.id
    lang = db.get_user_language(user_id)

    if target_id is not None and target_id == user_id:
        await message.answer(TEXTS[lang]["cannot_add_self"])
        return

    await state.update_data(target_id=target_id)
    await state.set_state(AddDebt.choosing_currency)
    await message.answer(TEXTS[lang]["choose_currency"], reply_markup=currency_keyboard())


@router.message(AddDebt.entering_recipient, F.content_type == ContentType.CONTACT)
async def add_debt_recipient_contact(message: Message, state: FSMContext) -> None:
    await _process_recipient(message, state, message.contact.user_id)


@router.message(AddDebt.entering_recipient, F.text)
async def add_debt_recipient_text(message: Message, state: FSMContext) -> None:
    user_id = message.from_user.id
    lang = db.get_user_language(user_id)

    if message.text in ALL_BTN_CANCEL:
        await state.clear()
        await message.answer(TEXTS[lang]["cancelled"], reply_markup=main_menu_keyboard(lang))
        return

    text = message.text.strip()
    target_id = None
    if text.lstrip("-").isdigit():
        target_id = int(text)
    elif text.startswith("@"):
        found = db.find_user_by_username(text)
        if found:
            target_id = found["user_id"]

    await _process_recipient(message, state, target_id)


@router.callback_query(AddDebt.choosing_currency, F.data.startswith("currency_"))
async def add_debt_currency(callback: CallbackQuery, state: FSMContext) -> None:
    currency = callback.data.replace("currency_", "", 1)
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id)

    await state.update_data(currency=currency)
    await state.set_state(AddDebt.entering_amount)
    await callback.message.answer(TEXTS[lang]["enter_amount"])
    await callback.answer()


@router.message(AddDebt.entering_amount, F.text)
async def add_debt_amount(message: Message, state: FSMContext, bot: Bot) -> None:
    user_id = message.from_user.id
    lang = db.get_user_language(user_id)

    if message.text in ALL_BTN_CANCEL:
        await state.clear()
        await message.answer(TEXTS[lang]["cancelled"], reply_markup=main_menu_keyboard(lang))
        return

    try:
        amount = float(message.text.replace(",", ".").strip())
        if amount <= 0:
            raise ValueError
    except ValueError:
        await message.answer(TEXTS[lang]["invalid_amount"])
        return

    data = await state.get_data()
    role = data["role"]
    target_id = data.get("target_id")
    currency = data["currency"]

    if role == "creditor":
        debtor_id, creditor_id = user_id, target_id
    else:
        debtor_id, creditor_id = target_id, user_id

    if target_id is not None:
        debt_id = db.create_debt(debtor_id, creditor_id, amount, currency, status="pending")
        other_lang = db.get_user_language(target_id)
        requester = db.get_user(user_id)
        role_text = (
            TEXTS[other_lang]["role_creditor"] if role == "creditor" else TEXTS[other_lang]["role_debtor"]
        )
        text = TEXTS[other_lang]["debt_confirm_request"].format(
            name=requester["full_name"], role=role_text, amount=amount, currency=currency
        )
        try:
            await bot.send_message(target_id, text, reply_markup=debt_confirm_keyboard(other_lang, debt_id))
            await message.answer(TEXTS[lang]["debt_request_sent"], reply_markup=main_menu_keyboard(lang))
        except Exception:
            await message.answer(
                TEXTS[lang]["debt_request_send_failed"], reply_markup=main_menu_keyboard(lang)
            )
    else:
        if role == "creditor":
            debt_id = db.create_debt(user_id, None, amount, currency, status="pending")
        else:
            debt_id = db.create_debt(None, user_id, amount, currency, status="pending")

        link = f"https://t.me/{BOT_USERNAME}?start=debt_{debt_id}"
        await message.answer(
            TEXTS[lang]["debt_link_generated"].format(link=link),
            reply_markup=main_menu_keyboard(lang),
        )

    await state.clear()


@router.callback_query(F.data.startswith("debt_confirm_"))
async def confirm_debt(callback: CallbackQuery, bot: Bot) -> None:
    debt_id = callback.data.replace("debt_confirm_", "", 1)
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id)

    debt = db.get_debt(debt_id)
    if not debt or debt.get("status") != "pending":
        await callback.answer(TEXTS[lang]["debt_not_found"], show_alert=True)
        return

    db.update_debt_status(debt_id, "active")
    await callback.message.edit_text(TEXTS[lang]["debt_confirmed_by_you"])
    await callback.answer()

    other_id = debt["creditor_id"] if debt["debtor_id"] == user_id else debt["debtor_id"]
    if other_id:
        other_lang = db.get_user_language(other_id)
        confirmer = db.get_user(user_id)
        try:
            await bot.send_message(
                other_id,
                TEXTS[other_lang]["debt_confirmed_by_other"].format(name=confirmer["full_name"]),
            )
        except Exception:
            pass


@router.callback_query(F.data.startswith("debt_reject_"))
async def reject_debt(callback: CallbackQuery, bot: Bot) -> None:
    debt_id = callback.data.replace("debt_reject_", "", 1)
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id)

    debt = db.get_debt(debt_id)
    if not debt or debt.get("status") != "pending":
        await callback.answer(TEXTS[lang]["debt_not_found"], show_alert=True)
        return

    db.update_debt_status(debt_id, "closed")
    await callback.message.edit_text(TEXTS[lang]["debt_rejected_by_you"])
    await callback.answer()

    other_id = debt["creditor_id"] if debt["debtor_id"] == user_id else debt["debtor_id"]
    if other_id:
        other_lang = db.get_user_language(other_id)
        rejecter = db.get_user(user_id)
        try:
            await bot.send_message(
                other_id,
                TEXTS[other_lang]["debt_rejected_by_other"].format(name=rejecter["full_name"]),
            )
        except Exception:
            pass
